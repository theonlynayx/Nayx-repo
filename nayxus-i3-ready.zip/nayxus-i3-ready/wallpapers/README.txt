Place ton fichier nayxus-default.png ici.
