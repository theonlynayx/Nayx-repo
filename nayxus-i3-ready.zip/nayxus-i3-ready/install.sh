#!/usr/bin/env bash
set -euo pipefail

if [[ "$EUID" -ne 0 ]]; then
  echo "Lance avec : sudo ./install.sh"
  exit 1
fi

TARGET_USER="${SUDO_USER:-}"
if [[ -z "$TARGET_USER" || "$TARGET_USER" == "root" ]]; then
  echo "Lance depuis une session utilisateur normale : sudo ./install.sh"
  exit 1
fi

TARGET_HOME="$(getent passwd "$TARGET_USER" | cut -d: -f6)"

echo "=== Nayxus i3 (VM SAFE) Installer ==="

echo "[1/4] Mise à jour système..."
pacman -Syu --noconfirm

echo "[2/4] Installation des paquets X11 + i3..."

pacman -S --needed --noconfirm   xorg-server xorg-xinit xorg-xrandr xorg-xsetroot xorg-xinput   i3-wm i3status dmenu   networkmanager network-manager-applet   firefox   xterm   feh   git rsync dbus

echo "[3/4] Activation des services..."
systemctl enable NetworkManager
systemctl enable dbus

echo "[4/4] Déploiement de la configuration Nayxus i3..."

for item in .config .xinitrc; do
  if [[ -e "$TARGET_HOME/$item" && ! -e "$TARGET_HOME/$item.nayxus.bak" ]]; then
    mv "$TARGET_HOME/$item" "$TARGET_HOME/$item.nayxus.bak"
  fi
done

mkdir -p "$TARGET_HOME/.config/i3"
mkdir -p "$TARGET_HOME/.config/i3status"
mkdir -p /usr/share/backgrounds/nayxus

cat <<'EOF' > "$TARGET_HOME/.xinitrc"
nm-applet &
feh --bg-fill /usr/share/backgrounds/nayxus/nayxus-default.png &
exec i3
EOF

cat <<'EOF' > "$TARGET_HOME/.config/i3/config"
set $mod Mod4
font pango:DejaVu Sans Mono 10

set $terminal xterm
set $menu dmenu_run

bindsym $mod+Return exec $terminal
bindsym $mod+d exec $menu
bindsym $mod+e exec firefox
bindsym $mod+Shift+q kill
bindsym $mod+Shift+r restart
bindsym $mod+Shift+e exit

floating_modifier $mod

set $ws1 "1"
set $ws2 "2"
set $ws3 "3"
set $ws4 "4"
set $ws5 "5"

bindsym $mod+1 workspace $ws1
bindsym $mod+2 workspace $ws2
bindsym $mod+3 workspace $ws3
bindsym $mod+4 workspace $ws4
bindsym $mod+5 workspace $ws5

bindsym $mod+Shift+1 move container to workspace $ws1
bindsym $mod+Shift+2 move container to workspace $ws2
bindsym $mod+Shift+3 move container to workspace $ws3
bindsym $mod+Shift+4 move container to workspace $ws4
bindsym $mod+Shift+5 move container to workspace $ws5

bar { status_command i3status }
EOF

cat <<'EOF' > "$TARGET_HOME/.config/i3status/config"
general { colors = true interval = 5 }
order += "disk /"
order += "wireless _first_"
order += "ethernet _first_"
order += "battery all"
order += "load"
order += "tztime local"

tztime local { format = "%Y-%m-%d %H:%M" }
battery all { format = "%status %percentage" }
wireless _first_ { format_up = "WiFi: %quality" format_down = "WiFi: down" }
EOF

chown -R "$TARGET_USER:$TARGET_USER" "$TARGET_HOME"

echo "Installation terminée."
echo "1) Mets ton wallpaper Nayxus dans /usr/share/backgrounds/nayxus/nayxus-default.png"
echo "2) Connecte-toi avec ton user"
echo "3) Lance : startx"
